from Framework import *

# Configure your Global variables here as below.
### setGlobal("<variable_name>",<variable_value>)

# You can get these variable value in your script as below
### getGlobal("<variable_name>")


